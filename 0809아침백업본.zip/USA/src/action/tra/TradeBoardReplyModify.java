package action.tra;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Command;
import model.tra.TradeBoardreplyDAO;

public class TradeBoardReplyModify implements Command {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		boolean flag=false;
		//댓글 고유 번호
		int trarep_num=Integer.parseInt(request.getParameter("trarep_num"));
		//내용
		String trarep_contents=request.getParameter("trarep_contents");
		int tradeboardnum=Integer.parseInt(request.getParameter("tradeboardnum"));
		TradeBoardreplyDAO dao=new TradeBoardreplyDAO();
	
		flag=dao.replyupdate(trarep_num, trarep_contents);
		
		if(flag) {
			return "/view/tra/content.do?num="+tradeboardnum;
		}
		return "/view/tra/content.do?num="+tradeboardnum;
	}

}
