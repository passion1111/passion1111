package controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import model.tra.TradeBoardreplyDAO;
import model.tra.TradeBoardreplyVO;


/**
 * Servlet implementation class Test2
 */
@WebServlet("/Test2")
public class Test2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter writer = response.getWriter();
		//받을떄
//		String jsoninfp=request.getParameter("data");
//		System.out.println(jsoninfp);
//		JSONParser jsonParser=new JSONParser();
//		try {
//			
//				
//				JSONObject jsonObject = (JSONObject) jsonParser.parse(jsoninfp);
//				System.out.println(jsonObject.get("age"));
//			
////			
////			
//		} catch (ParseException e) {
//			e.printStackTrace();
//		}
//	이부분까지 데이터받는거없을떄지우기	
		
		
		
		//보낼떄 아래 되는버전까지 정상버전
//		JSONObject totalObject = new JSONObject();
//		JSONArray membersArray = new JSONArray();
//		JSONObject memberInfo = new JSONObject();
//		TradeBoardreplyDAO dao=new TradeBoardreplyDAO();
//		TradeBoardreplyVO vo=new TradeBoardreplyVO();
//		ArrayList<TradeBoardreplyVO> list=new  ArrayList<TradeBoardreplyVO>();
//		
//		list=dao.getreplylist(21);
//		int i2=list.size();
//		for(int i=0;i<i2;i++) {
//			memberInfo.put("name", list.get(i).getTrarep_contents());
//			memberInfo.put("age", list.get(i).getTrarep_num());
//			memberInfo.put("gender", list.get(i).getTrarep_writer());
//			memberInfo.put("nickname", list.get(i).getTrarep_tranum());
//			memberInfo.put("아아","아아");
//			membersArray.add(memberInfo);
//			
//			
//		}//되는버전
		
		
		
		
//		memberInfo.put("name", "박지성");
//		memberInfo.put("age", "25");
//		memberInfo.put("gender", "남자");
//		memberInfo.put("nickname", "날센돌이");
//        //  배열에 입력
//		membersArray.add(memberInfo);
//
//		memberInfo = new JSONObject();
//		memberInfo.put("name", "김연아");
//		memberInfo.put("age", "21");
//		memberInfo.put("gender", "여자");
//		memberInfo.put("nickname", "칼치");
//		membersArray.add(memberInfo);

		
		
		
		
		///여기부터 세션체크할려고 적는것
		JSONObject totalObject = new JSONObject();
		JSONArray  replyarray = new JSONArray();
		JSONObject replyinfo = new JSONObject();
		TradeBoardreplyDAO dao=new TradeBoardreplyDAO();
		TradeBoardreplyVO vo=new TradeBoardreplyVO();
		ArrayList<TradeBoardreplyVO> list=new  ArrayList<TradeBoardreplyVO>();
		list=dao.getreplylist(21);
		
		System.out.println(list.size());
		for(int i=0;i<list.size();i++) {
			replyinfo.put("content", list.get(i).getTrarep_contents());
			replyinfo.put("num", list.get(i).getTrarep_num());
			replyinfo.put("writer", list.get(i).getTrarep_writer());
			replyinfo.put("tranum", list.get(i).getTrarep_tranum());
			replyinfo.put("아아","아아");
			replyarray.add(replyinfo);
		
		
	}
		totalObject.put("replyinfo", replyarray);
//

		
		
		
		
		
		String i =(String) request.getSession().getAttribute("member");
		JSONArray jsonsession=new JSONArray();
		JSONObject jsonobject=new JSONObject();
		jsonobject.put("session",i);
		jsonsession.add(jsonobject);
		totalObject.put("session",jsonsession);
		
		String jsonInfo = totalObject.toJSONString();
		System.out.print(jsonInfo);
		writer.print(jsonInfo);
		
		
		
		//여기까지
		
	
		//되는버전
//		totalObject.put("members", membersArray);
//
//		String jsonInfo = totalObject.toJSONString();
//		System.out.print(jsonInfo);
//		writer.print(jsonInfo);


	
}
}