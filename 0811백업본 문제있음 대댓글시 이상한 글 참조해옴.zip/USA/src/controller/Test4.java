package controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import model.tra.TradeBoardreplyDAO;
import model.tra.TradeBoardreplyVO;


/**
 * Servlet implementation class Test2
 */
@WebServlet("/Test4")
public class Test4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		TradeBoardreplyDAO2 dao=new TradeBoardreplyDAO2();
		TradeBoardreplyVO2 vo=new  TradeBoardreplyVO2();
		boolean result=false;
		PrintWriter writer = response.getWriter();
		//받을떄
		
		String jsoninfo=request.getParameter("data");
		System.out.println(jsoninfo);
		JSONParser jsonParser=new JSONParser();
	
		try {
			
				
				JSONObject jsonObject = (JSONObject) jsonParser.parse(jsoninfo);
				System.out.println(jsonObject);
				//json값 가져올떄 long형으로 가져옴
				/*
				 contet 글 내용
				 writer 작성자
				 ref  답글인지 아닌지  1일떄 부모 작성자번호 누구의 대댓글인지 판단할것.
				 numlv 답글 순서
				 tranum 게시판 번호
				 
				 받아와야할것
				
				  
				 */
				//댓글 고유번호
			int    trarepnum=dao.getreplynum();
			int trarepTranum=(int)(long)jsonObject.get("tranum");
			String trarepContent=  (String) jsonObject.get("content");
			String trarepWriter=(String) jsonObject.get("writer");
			int ref= Integer.parseInt((String) jsonObject.get("ref"));
			int trarepWriternum=0;
			if(ref==0) trarepWriternum=trarepnum;
			String trareprepwriter=null;
			int trarepNumlv=0;
			if(ref==1) {
				trareprepwriter=(String)jsonObject.get("wrtierrepwriter");//누구의 대댓글인지.
				trarepWriternum=(int)(long) jsonObject.get("writernum");//부모작성자번호
				trarepNumlv=(int)(long)jsonObject.get("numlv"); //답글순서
				
			}
//		
		System.out.println("등록전 여기는 test4"+trarepTranum);
			//1댓글 고유번호
			vo.setTrarep_num(trarepnum);
			//2게시판 번호
			vo.setTrarep_tranum(trarepTranum);
			//3내용
			vo.setTrarep_contents(trarepContent);
			//4작성자
			vo.setTrarep_writer(trarepWriter);
			//5부모작성자 번호
			vo.setTrarep_writerrep(trarepWriternum);
			//6.대댓글 유무
			vo.setTrarep_numref(ref);
			//6.1 대댓글이라면 누구의 대댓글인지
			vo.setTrarep_writerrepwriter(trareprepwriter);
			//7.대댓글 순서
			vo.setTrarep_numref_lv(trarepNumlv);
			
			result = dao.insertReply(vo);
			
			
	

		} catch (ParseException e) {
			e.printStackTrace();
		}
		String msg = null;
		if(!result) {
			msg="댓글 등록에 실패하셨습니다.";
		}
		
// 댓글 성공인지 적는것
		JSONObject totalObject = new JSONObject();
		

		totalObject.put("result",msg);
//		
//		String jsonInfo = totalObject.toJSONString();
//		System.out.print(jsonInfo);
		writer.print(totalObject);
//		
//		
//		

	
}
}