package lib.employee.book.model;

public class Book_categoryDTO {
	private String book_ctgr_num; //분류기호
	private String book_ctgr_name; //분류명
	  	
	public String getBook_ctgr_num() {
		return book_ctgr_num;
	}

	public void setBook_ctgr_num(String book_ctgr_num) {
		this.book_ctgr_num = book_ctgr_num;
	}

	public String getBook_ctgr_name() {
		return book_ctgr_name;
	}

	public void setBook_ctgr_name(String book_ctgr_name) {
		this.book_ctgr_name = book_ctgr_name;
	}
	  
}
