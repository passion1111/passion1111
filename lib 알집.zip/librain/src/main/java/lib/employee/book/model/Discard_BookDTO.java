package lib.employee.book.model;

public class Discard_BookDTO {
	private int dis_book_num; //폐기 신청 번호
	private int book_num;
	
	public int getDis_book_num() {
		return dis_book_num;
	}

	public void setDis_book_num(int dis_book_num) {
		this.dis_book_num = dis_book_num;
	}

	public int getBook_num() {
		return book_num;
	}

	public void setBook_num(int book_num) {
		this.book_num = book_num;
	}

	
	
}
