package lib.book.scheduled;

public interface BookScheduledDAO {
	
	
	public void rentservationAutoReturn();
	public void rentStop();
	public void rentAvailable();
}
