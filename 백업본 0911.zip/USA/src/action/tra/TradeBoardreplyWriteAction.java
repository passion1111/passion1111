package action.tra;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Command;
import model.tra.TradeBoardreplyDAO;
import model.tra.TradeBoardreplyVO;

public class TradeBoardreplyWriteAction implements Command {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		TradeBoardreplyDAO dao = TradeBoardreplyDAO.getInstance();
		TradeBoardreplyVO  vo  = new TradeBoardreplyVO();
		
		String 
		//2게시판 번호
		int tradeBoardNum=Integer.parseInt(request.getParameter("tradeboardnum"));
		//3내용
		String tradeBoardreplyContents=request.getParameter("TradeBoardreply_Content");
		//4작성자
		String tradeBoardreplyWriter=request.getParameter("tradecontentcomment_id");
		//5부모작성자 번호
		int tradeBoardreplyWriterNum=vo.getTrarep_writerrep();
		//6.대댓글 유무
		int tradeBoardreplyNumRef=Integer.parseInt(request.getParameter("ref"));
		//7.대댓글 순서
		int tradeBoarReplyNumlv=0;
		if(tradeBoardreplyNumRef!=0)	 tradeBoarReplyNumlv= dao.getreplynumlv(tradeBoardreplyWriterNum, tradeBoardreplyNumRef);
	
		//1댓글 고유번호
			int tradeBoardReplyNum =	dao.getreplynum(tradeBoardNum);
		
		
		
				//1댓글 고유번호
				vo.setTrarep_num(tradeBoardReplyNum);
				//2게시판 번호
				vo.setTrarep_tranum(tradeBoardNum);
				//3내용
				vo.setTrarep_contents(tradeBoardreplyContents);
				//4작성자
				vo.setTrarep_writer(tradeBoardreplyWriter);
				//5부모작성자 번호
				vo.setTrarep_writerrep(tradeBoardreplyWriterNum);
				//6.대댓글 유무
				vo.setTrarep_numref(tradeBoardreplyNumRef);
				//7.대댓글 순서
				vo.setTrarep_numref_lv(tradeBoarReplyNumlv);;
		
		boolean result = dao.insertReply(vo);

		if(result){
//			response.setContentType("text/html;charset=euc-kr");
//			PrintWriter out = response.getWriter();
//			out.println("1");
//			out.close();
		return null;
	}
		
		
		return null;
	}
}


	
