package model.reg;

public class RegVO {
	
	private int reg_num;
	private String reg_name;
	private String reg_subject;
	private String reg_contents;
	private String reg_filename;
	
	public int getReg_num() {
		return reg_num;
	}
	public void setReg_num(int reg_num) {
		this.reg_num = reg_num;
	}
	public String getReg_name() {
		return reg_name;
	}
	public void setReg_name(String reg_name) {
		this.reg_name = reg_name;
	}
	public String getReg_subject() {
		return reg_subject;
	}
	public void setReg_subject(String reg_subject) {
		this.reg_subject = reg_subject;
	}
	public String getReg_contents() {
		return reg_contents;
	}
	public void setReg_contents(String reg_contents) {
		this.reg_contents = reg_contents;
	}
	public String getReg_filename() {
		return reg_filename;
	}
	public void setReg_filename(String reg_filename) {
		this.reg_filename = reg_filename;
	}
	
}
