package model.loc;

public class test {

}
